using UnityEngine;

public class BossMarker : MonoBehaviour { }
