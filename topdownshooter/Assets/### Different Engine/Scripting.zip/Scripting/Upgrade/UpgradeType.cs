public enum UpgradeType
{
    FireRate,
    BulletSpeed,
    BulletCount,
    PickupRadius,
    AuraUnlock,
    AuraDamage,
    AuraRadius,
    BulletDamage,
    MaxHealth,
    HealthRegen,
    AOEAttack
}
